using UnityEngine;

public class Status : MonoBehaviour
{
    public int coins;
    public float hp;
    public float maxHp = 100f;

    public void AddCoin()
    {
        coins++;
    }

    public void TakeDamage(float damage)
    {
        hp -= damage;
        if (hp <= 0)
        {
            Die();
        }
    }

    public void Heal(float amount)
    {
        hp = Mathf.Min(hp + amount, maxHp);
    }
    

    private void Die()
    {
        // Add logic for player death
    }

    void Start()
    {
        hp = maxHp; // Initialize hp to maxHp at the start 
        coins = 0; // Initialize coins to 0 at the start
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.H))
        {
            Heal(20);
        }
        
        if (Input.GetKeyDown(KeyCode.C))
        {
            AddCoin();
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            TakeDamage(20);
        }

        void OnCollisionEnter(Collision collision)
        {
            if (collision.gameObject.CompareTag("Enemy"))
            {
                TakeDamage(10);
            }
        }

     
    }


}

